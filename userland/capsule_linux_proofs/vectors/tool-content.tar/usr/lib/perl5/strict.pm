package strict;
1;
